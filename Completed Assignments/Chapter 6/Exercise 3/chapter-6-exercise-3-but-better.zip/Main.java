import java.util.Scanner;
public class Main
{
  public static void main (String[]args)
  {
    Scanner input = new Scanner (System.in);
      System.out.println ("Please enter the principal amount: ");
    double principal = input.nextDouble ();
      System.out.println ("Please enter the desired amount: ");
    double ending = input.nextDouble ();
      System.out.println ("Please enter the interest rate: ");
    double interest = input.nextDouble ();
    double time = Math.log (ending / principal) / Math.log (1 d + interest);
      System.out.println ("It will take " + Math.round (time) + " years.");
  }
}
